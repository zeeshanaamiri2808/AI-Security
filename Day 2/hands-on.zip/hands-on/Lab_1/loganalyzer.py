"""
Security Log Analyzer - Flask Application
Built by Zeeshan for Hands-On
"""

from flask import Flask, render_template_string, request, jsonify
import json
import csv
import io
from datetime import datetime
import os

# Initialize Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# OpenAI Configuration (Hardcoded)
OPENAI_API_KEY = "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"  # Replace with your actual OpenAI API key
OPENAI_MODEL = "gpt-4"

# HTML Template with Modern UI
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Log Analyzer - Built by Zeeshan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: fadeIn 0.8s ease-in;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .header .subtitle {
            font-size: 1.2em;
            opacity: 0.9;
            font-weight: 300;
        }

        .credit {
            text-align: center;
            color: rgba(255,255,255,0.8);
            margin-top: 10px;
            font-style: italic;
        }

        .main-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 40px;
            animation: slideUp 0.8s ease-out;
        }

        .upload-section {
            border: 3px dashed #667eea;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
            transition: all 0.3s ease;
            background: #f8f9ff;
        }

        .upload-section:hover {
            border-color: #764ba2;
            background: #f0f2ff;
        }

        .upload-section.dragover {
            background: #e8ebff;
            border-color: #764ba2;
            transform: scale(1.02);
        }

        .file-input-wrapper {
            position: relative;
            display: inline-block;
            margin: 20px 0;
        }

        input[type="file"] {
            display: none;
        }

        .custom-file-upload {
            display: inline-block;
            padding: 15px 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .custom-file-upload:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }

        .file-info {
            margin-top: 15px;
            color: #666;
            font-size: 14px;
        }

        .analyze-btn {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            padding: 15px 50px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(245, 87, 108, 0.4);
            margin-top: 20px;
        }

        .analyze-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(245, 87, 108, 0.6);
        }

        .analyze-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .loading {
            display: none;
            text-align: center;
            margin: 30px 0;
        }

        .loading.active {
            display: block;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }

        .results-section {
            display: none;
            margin-top: 30px;
            animation: fadeIn 0.5s ease-in;
        }

        .results-section.active {
            display: block;
        }

        .result-card {
            background: #f8f9ff;
            border-left: 5px solid #667eea;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .result-card h3 {
            color: #667eea;
            margin-bottom: 15px;
            font-size: 1.5em;
        }

        .severity-critical {
            border-left-color: #dc3545;
        }

        .severity-high {
            border-left-color: #fd7e14;
        }

        .severity-medium {
            border-left-color: #ffc107;
        }

        .severity-low {
            border-left-color: #28a745;
        }

        .severity-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .badge-critical {
            background: #dc3545;
            color: white;
        }

        .badge-high {
            background: #fd7e14;
            color: white;
        }

        .badge-medium {
            background: #ffc107;
            color: #333;
        }

        .badge-low {
            background: #28a745;
            color: white;
        }

        .finding-item {
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border-left: 3px solid #667eea;
        }

        .finding-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }

        .finding-description {
            color: #666;
            line-height: 1.6;
        }

        .recommendations {
            background: #e8f5e9;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }

        .recommendations h4 {
            color: #2e7d32;
            margin-bottom: 10px;
        }

        .recommendations ul {
            margin-left: 20px;
        }

        .recommendations li {
            margin: 5px 0;
            color: #333;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }

        .stat-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .stat-number {
            font-size: 2em;
            font-weight: 700;
            color: #667eea;
        }

        .stat-label {
            color: #666;
            font-size: 0.9em;
            margin-top: 5px;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .supported-formats {
            color: #666;
            font-size: 14px;
            margin-top: 15px;
        }

        .format-badge {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 3px 10px;
            border-radius: 3px;
            margin: 0 5px;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 Security Log Analyzer</h1>
            <div class="subtitle">AI-Powered Security Analysis for Your Logs</div>
            <div class="credit">Built by Zeeshan for Hands-On</div>
        </div>

        <div class="main-card">
            <div class="upload-section" id="dropZone">
                <h2>📁 Upload Your Log File</h2>
                <p style="color: #666; margin: 15px 0;">
                    Drag and drop your file here or click to browse
                </p>
                
                <div class="file-input-wrapper">
                    <label for="fileInput" class="custom-file-upload">
                        Choose File
                    </label>
                    <input type="file" id="fileInput" accept=".txt,.json,.csv" />
                </div>
                
                <div class="file-info" id="fileInfo">
                    No file selected
                </div>

                <div class="supported-formats">
                    Supported formats: 
                    <span class="format-badge">.TXT</span>
                    <span class="format-badge">.JSON</span>
                    <span class="format-badge">.CSV</span>
                </div>

                <button class="analyze-btn" id="analyzeBtn" disabled>
                    🔍 Analyze Logs
                </button>
            </div>

            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p style="color: #667eea; font-weight: 600;">Analyzing your logs... This may take a moment.</p>
            </div>

            <div class="results-section" id="results">
                <!-- Results will be inserted here -->
            </div>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('fileInput');
        const fileInfo = document.getElementById('fileInfo');
        const analyzeBtn = document.getElementById('analyzeBtn');
        const loading = document.getElementById('loading');
        const results = document.getElementById('results');
        const dropZone = document.getElementById('dropZone');

        let selectedFile = null;

        // File input change handler
        fileInput.addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                selectedFile = e.target.files[0];
                const fileSize = (selectedFile.size / 1024).toFixed(2);
                fileInfo.textContent = `Selected: ${selectedFile.name} (${fileSize} KB)`;
                analyzeBtn.disabled = false;
            }
        });

        // Drag and drop handlers
        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const file = files[0];
                const ext = file.name.split('.').pop().toLowerCase();
                
                if (['txt', 'json', 'csv'].includes(ext)) {
                    selectedFile = file;
                    const fileSize = (selectedFile.size / 1024).toFixed(2);
                    fileInfo.textContent = `Selected: ${selectedFile.name} (${fileSize} KB)`;
                    analyzeBtn.disabled = false;
                } else {
                    alert('Please upload a .txt, .json, or .csv file');
                }
            }
        });

        // Analyze button handler
        analyzeBtn.addEventListener('click', async function() {
            if (!selectedFile) return;

            const formData = new FormData();
            formData.append('file', selectedFile);

            analyzeBtn.disabled = true;
            loading.classList.add('active');
            results.classList.remove('active');
            results.innerHTML = '';

            try {
                const response = await fetch('/analyze', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.error) {
                    throw new Error(data.error);
                }

                displayResults(data);
            } catch (error) {
                results.innerHTML = `
                    <div class="result-card severity-critical">
                        <h3>❌ Error</h3>
                        <p>${error.message}</p>
                    </div>
                `;
                results.classList.add('active');
            } finally {
                loading.classList.remove('active');
                analyzeBtn.disabled = false;
            }
        });

        function displayResults(data) {
            let html = '';

            // Summary statistics
            if (data.summary) {
                html += `
                    <div class="result-card">
                        <h3>📊 Analysis Summary</h3>
                        <div class="stats-grid">
                            <div class="stat-box">
                                <div class="stat-number">${data.summary.total_findings || 0}</div>
                                <div class="stat-label">Total Findings</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number" style="color: #dc3545;">${data.summary.critical || 0}</div>
                                <div class="stat-label">Critical</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number" style="color: #fd7e14;">${data.summary.high || 0}</div>
                                <div class="stat-label">High</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number" style="color: #ffc107;">${data.summary.medium || 0}</div>
                                <div class="stat-label">Medium</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-number" style="color: #28a745;">${data.summary.low || 0}</div>
                                <div class="stat-label">Low</div>
                            </div>
                        </div>
                    </div>
                `;
            }

            // Security findings
            if (data.findings && data.findings.length > 0) {
                html += `<div class="result-card">
                    <h3>🔍 Security Findings</h3>
                `;

                data.findings.forEach((finding, index) => {
                    const severityClass = `severity-${finding.severity.toLowerCase()}`;
                    const badgeClass = `badge-${finding.severity.toLowerCase()}`;
                    
                    html += `
                        <div class="finding-item">
                            <span class="severity-badge ${badgeClass}">${finding.severity.toUpperCase()}</span>
                            <div class="finding-title">${index + 1}. ${finding.title}</div>
                            <div class="finding-description">${finding.description}</div>
                            ${finding.details ? `<div style="margin-top: 10px; color: #888; font-size: 0.9em;">${finding.details}</div>` : ''}
                        </div>
                    `;
                });

                html += `</div>`;
            }

            // Recommendations
            if (data.recommendations && data.recommendations.length > 0) {
                html += `
                    <div class="result-card">
                        <div class="recommendations">
                            <h4>💡 Recommendations</h4>
                            <ul>
                `;

                data.recommendations.forEach(rec => {
                    html += `<li>${rec}</li>`;
                });

                html += `
                            </ul>
                        </div>
                    </div>
                `;
            }

            // Overall assessment
            if (data.overall_assessment) {
                html += `
                    <div class="result-card">
                        <h3>📝 Overall Assessment</h3>
                        <p style="line-height: 1.6; color: #333;">${data.overall_assessment}</p>
                    </div>
                `;
            }

            results.innerHTML = html;
            results.classList.add('active');
        }
    </script>
</body>
</html>
"""

def analyze_logs_with_openai(log_content, file_type):
    """
    Analyze logs using OpenAI API
    """
    try:
        import openai
        
        openai.api_key = OPENAI_API_KEY
        
        # Prepare the prompt for security analysis
        prompt = f"""You are a cybersecurity expert analyzing log files for security vulnerabilities and threats.

Analyze the following {file_type.upper()} log file and provide a comprehensive security analysis:

{log_content[:4000]}  # Limiting content to avoid token limits

Please provide your analysis in the following JSON format:
{{
    "summary": {{
        "total_findings": <number>,
        "critical": <number>,
        "high": <number>,
        "medium": <number>,
        "low": <number>
    }},
    "findings": [
        {{
            "severity": "Critical|High|Medium|Low",
            "title": "Brief title of the finding",
            "description": "Detailed description",
            "details": "Specific log entries or patterns found"
        }}
    ],
    "recommendations": [
        "Actionable recommendation 1",
        "Actionable recommendation 2"
    ],
    "overall_assessment": "Overall security posture assessment"
}}

Focus on:
- Failed authentication attempts
- Unauthorized access attempts
- Unusual patterns or anomalies
- Potential intrusion attempts
- Configuration issues
- Suspicious IP addresses
- Error patterns that indicate security issues
- Any other security-relevant observations"""

        # Make API call to OpenAI
        response = openai.ChatCompletion.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "You are a cybersecurity expert specializing in log analysis and security threat detection."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=2000
        )
        
        # Parse the response
        analysis_text = response.choices[0].message.content
        
        # Try to extract JSON from the response
        try:
            # Find JSON content in the response
            start_idx = analysis_text.find('{')
            end_idx = analysis_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx > start_idx:
                json_str = analysis_text[start_idx:end_idx]
                analysis_data = json.loads(json_str)
            else:
                # If no JSON found, create a structured response
                analysis_data = create_fallback_analysis(analysis_text)
        except json.JSONDecodeError:
            analysis_data = create_fallback_analysis(analysis_text)
        
        return analysis_data
        
    except Exception as e:
        return {
            "error": f"OpenAI API Error: {str(e)}",
            "summary": {"total_findings": 0, "critical": 0, "high": 0, "medium": 0, "low": 0},
            "findings": [],
            "recommendations": ["Please check your OpenAI API key and try again."],
            "overall_assessment": "Analysis could not be completed due to an error."
        }

def create_fallback_analysis(text):
    """
    Create a fallback analysis structure when JSON parsing fails
    """
    return {
        "summary": {
            "total_findings": 1,
            "critical": 0,
            "high": 0,
            "medium": 1,
            "low": 0
        },
        "findings": [
            {
                "severity": "Medium",
                "title": "Analysis Completed",
                "description": text[:500],
                "details": "Full analysis response from AI"
            }
        ],
        "recommendations": [
            "Review the detailed analysis above",
            "Check for any mentioned security issues",
            "Implement suggested security measures"
        ],
        "overall_assessment": "Analysis completed. Please review the findings above."
    }

def perform_basic_security_analysis(log_content, file_type):
    """
    Perform basic security analysis without OpenAI (fallback)
    """
    findings = []
    critical = high = medium = low = 0
    
    log_lower = log_content.lower()
    
    # Check for failed authentication
    if 'failed' in log_lower and ('login' in log_lower or 'auth' in log_lower or 'password' in log_lower):
        findings.append({
            "severity": "High",
            "title": "Failed Authentication Attempts Detected",
            "description": "Multiple failed authentication attempts found in logs",
            "details": "This could indicate a brute force attack attempt"
        })
        high += 1
    
    # Check for errors
    if 'error' in log_lower or 'exception' in log_lower:
        findings.append({
            "severity": "Medium",
            "title": "Errors Detected in Logs",
            "description": "System errors or exceptions found",
            "details": "Errors may indicate system instability or potential security issues"
        })
        medium += 1
    
    # Check for suspicious patterns
    if 'unauthorized' in log_lower or 'forbidden' in log_lower or '403' in log_content:
        findings.append({
            "severity": "High",
            "title": "Unauthorized Access Attempts",
            "description": "Attempts to access unauthorized resources detected",
            "details": "Review access controls and monitor for patterns"
        })
        high += 1
    
    # Check for SQL injection patterns
    if 'select' in log_lower and ('union' in log_lower or 'drop' in log_lower or "' or" in log_lower):
        findings.append({
            "severity": "Critical",
            "title": "Potential SQL Injection Attempt",
            "description": "Log entries contain patterns consistent with SQL injection attempts",
            "details": "Immediate review and WAF configuration recommended"
        })
        critical += 1
    
    # Check for XSS patterns
    if '<script>' in log_lower or 'javascript:' in log_lower:
        findings.append({
            "severity": "High",
            "title": "Potential XSS Attack Detected",
            "description": "Script injection patterns found in logs",
            "details": "Review input validation and output encoding"
        })
        high += 1
    
    if not findings:
        findings.append({
            "severity": "Low",
            "title": "No Critical Issues Detected",
            "description": "Basic analysis did not find obvious security threats",
            "details": "Continue monitoring and consider deeper analysis"
        })
        low += 1
    
    return {
        "summary": {
            "total_findings": len(findings),
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low
        },
        "findings": findings,
        "recommendations": [
            "Enable comprehensive logging and monitoring",
            "Implement rate limiting for authentication endpoints",
            "Regular security audits and penetration testing",
            "Keep systems and dependencies updated",
            "Use Web Application Firewall (WAF)"
        ],
        "overall_assessment": f"Analyzed {file_type.upper()} log file. {len(findings)} security finding(s) identified. " + 
                            ("Critical issues require immediate attention." if critical > 0 else 
                             "High priority issues should be addressed soon." if high > 0 else
                             "Continue monitoring for security events.")
    }

@app.route('/')
def index():
    """Render the main page"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/analyze', methods=['POST'])
def analyze():
    """Handle file upload and analysis"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get file extension
        filename = file.filename.lower()
        if not (filename.endswith('.txt') or filename.endswith('.json') or filename.endswith('.csv')):
            return jsonify({'error': 'Invalid file type. Please upload .txt, .json, or .csv file'}), 400
        
        file_type = filename.split('.')[-1]
        
        # Read file content
        file_content = file.read().decode('utf-8', errors='ignore')
        
        # Parse based on file type
        if file_type == 'json':
            try:
                json_data = json.loads(file_content)
                # Convert JSON to readable string for analysis
                log_content = json.dumps(json_data, indent=2)
            except json.JSONDecodeError:
                log_content = file_content
        
        elif file_type == 'csv':
            try:
                csv_reader = csv.DictReader(io.StringIO(file_content))
                rows = list(csv_reader)
                # Convert CSV to readable string
                log_content = json.dumps(rows, indent=2)
            except:
                log_content = file_content
        
        else:  # txt
            log_content = file_content
        
        # Perform analysis
        # First try with OpenAI if API key is configured
        if OPENAI_API_KEY and OPENAI_API_KEY != "sk-your-api-key-here":
            analysis_result = analyze_logs_with_openai(log_content, file_type)
        else:
            # Fallback to basic analysis
            analysis_result = perform_basic_security_analysis(log_content, file_type)
        
        return jsonify(analysis_result)
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("Security Log Analyzer - Built by Zeeshan for Hands-On")
    print("=" * 60)
    print("\nStarting Flask server...")
    print("\n⚠️  IMPORTANT: Update your OpenAI API key in the code!")
    print(f"Current API key starts with: {OPENAI_API_KEY[:10]}...")
    print("\nAccess the application at: http://127.0.0.1:5000")
    print("\nSupported file formats: .txt, .json, .csv")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)