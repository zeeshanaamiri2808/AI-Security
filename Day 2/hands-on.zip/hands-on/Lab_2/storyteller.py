"""
Intelligent Attack Pattern Storyteller
Built by Zeeshan for Hands-On
"""

from flask import Flask, render_template_string, request, jsonify
import json
import csv
import io
from datetime import datetime
import re

# Initialize Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# OpenAI Configuration (Hardcoded)
OPENAI_API_KEY = "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"  # Replace with your actual OpenAI API key
OPENAI_MODEL = "gpt-4"

# HTML Template with Modern UI
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attack Pattern Storyteller - Built by Zeeshan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 50%, #7e22ce 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: fadeIn 0.8s ease-in;
        }

        .header h1 {
            font-size: 2.8em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        .header .icon {
            font-size: 3em;
            margin-bottom: 10px;
        }

        .header .subtitle {
            font-size: 1.3em;
            opacity: 0.9;
            font-weight: 300;
            margin-bottom: 5px;
        }

        .credit {
            text-align: center;
            color: rgba(255,255,255,0.85);
            margin-top: 10px;
            font-style: italic;
            font-size: 1.1em;
        }

        .main-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
            animation: slideUp 0.8s ease-out;
        }

        .upload-section {
            border: 3px dashed #2a5298;
            border-radius: 12px;
            padding: 40px;
            text-align: center;
            margin-bottom: 30px;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #f8f9ff 0%, #e8f0ff 100%);
        }

        .upload-section:hover {
            border-color: #7e22ce;
            background: linear-gradient(135deg, #f0f4ff 0%, #e0ebff 100%);
            transform: translateY(-2px);
        }

        .upload-section.dragover {
            background: linear-gradient(135deg, #e8f0ff 0%, #d8e8ff 100%);
            border-color: #7e22ce;
            transform: scale(1.02);
            box-shadow: 0 0 20px rgba(126, 34, 206, 0.3);
        }

        .file-input-wrapper {
            position: relative;
            display: inline-block;
            margin: 20px 0;
        }

        input[type="file"] {
            display: none;
        }

        .custom-file-upload {
            display: inline-block;
            padding: 18px 50px;
            background: linear-gradient(135deg, #2a5298 0%, #1e3c72 100%);
            color: white;
            border-radius: 10px;
            cursor: pointer;
            font-size: 17px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(42, 82, 152, 0.4);
        }

        .custom-file-upload:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(42, 82, 152, 0.6);
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        }

        .file-info {
            margin-top: 15px;
            color: #555;
            font-size: 15px;
            font-weight: 500;
        }

        .analyze-btn {
            background: linear-gradient(135deg, #7e22ce 0%, #a855f7 100%);
            color: white;
            border: none;
            padding: 18px 60px;
            border-radius: 10px;
            font-size: 19px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(126, 34, 206, 0.4);
            margin-top: 20px;
        }

        .analyze-btn:hover:not(:disabled) {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(126, 34, 206, 0.6);
            background: linear-gradient(135deg, #a855f7 0%, #7e22ce 100%);
        }

        .analyze-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .loading {
            display: none;
            text-align: center;
            margin: 40px 0;
        }

        .loading.active {
            display: block;
        }

        .spinner {
            border: 5px solid #f3f3f3;
            border-top: 5px solid #2a5298;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        .loading-text {
            color: #2a5298;
            font-weight: 600;
            font-size: 18px;
        }

        .results-section {
            display: none;
            margin-top: 40px;
            animation: fadeIn 0.5s ease-in;
        }

        .results-section.active {
            display: block;
        }

        .story-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .story-header h2 {
            font-size: 2em;
            margin-bottom: 15px;
        }

        .story-meta {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .meta-item {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            backdrop-filter: blur(10px);
        }

        .meta-label {
            font-size: 0.85em;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .meta-value {
            font-size: 1.3em;
            font-weight: 700;
        }

        .narrative-section {
            background: linear-gradient(135deg, #fff5f5 0%, #ffe5e5 100%);
            border-left: 6px solid #dc2626;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .narrative-section h3 {
            color: #dc2626;
            font-size: 1.8em;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .narrative-text {
            color: #333;
            line-height: 1.9;
            font-size: 1.05em;
            white-space: pre-wrap;
        }

        .timeline-section {
            background: #f8f9ff;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .timeline-section h3 {
            color: #2a5298;
            font-size: 1.8em;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .timeline-item {
            position: relative;
            padding-left: 40px;
            padding-bottom: 30px;
            border-left: 3px solid #2a5298;
            margin-left: 20px;
        }

        .timeline-item:last-child {
            border-left-color: transparent;
            padding-bottom: 0;
        }

        .timeline-dot {
            position: absolute;
            left: -9px;
            top: 5px;
            width: 15px;
            height: 15px;
            border-radius: 50%;
            background: #2a5298;
            border: 3px solid white;
            box-shadow: 0 0 0 3px #2a5298;
        }

        .timeline-time {
            color: #7e22ce;
            font-weight: 700;
            font-size: 0.95em;
            margin-bottom: 8px;
        }

        .timeline-event {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .timeline-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
            font-size: 1.05em;
        }

        .timeline-description {
            color: #666;
            line-height: 1.6;
            font-size: 0.95em;
        }

        .severity-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 700;
            margin-left: 10px;
            text-transform: uppercase;
        }

        .severity-critical {
            background: #dc2626;
            color: white;
        }

        .severity-high {
            background: #ea580c;
            color: white;
        }

        .severity-medium {
            background: #f59e0b;
            color: white;
        }

        .objectives-section {
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            border-left: 6px solid #f59e0b;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .objectives-section h3 {
            color: #d97706;
            font-size: 1.8em;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .objectives-list {
            list-style: none;
        }

        .objectives-list li {
            background: white;
            padding: 15px 15px 15px 50px;
            margin: 12px 0;
            border-radius: 8px;
            position: relative;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            color: #333;
            line-height: 1.7;
        }

        .objectives-list li:before {
            content: "🎯";
            position: absolute;
            left: 15px;
            font-size: 1.5em;
        }

        .recommendations-section {
            background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%);
            border-left: 6px solid #16a34a;
            padding: 30px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .recommendations-section h3 {
            color: #15803d;
            font-size: 1.8em;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .recommendations-list {
            list-style: none;
        }

        .recommendations-list li {
            background: white;
            padding: 15px 15px 15px 50px;
            margin: 12px 0;
            border-radius: 8px;
            position: relative;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            color: #333;
            line-height: 1.7;
        }

        .recommendations-list li:before {
            content: "✓";
            position: absolute;
            left: 15px;
            font-size: 1.8em;
            color: #16a34a;
            font-weight: bold;
        }

        .iocs-section {
            background: #f8f9ff;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }

        .iocs-section h3 {
            color: #2a5298;
            font-size: 1.8em;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .iocs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .ioc-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .ioc-type {
            color: #7e22ce;
            font-weight: 700;
            font-size: 0.9em;
            text-transform: uppercase;
            margin-bottom: 10px;
        }

        .ioc-values {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .ioc-value {
            background: #f1f5f9;
            padding: 10px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            color: #334155;
            word-break: break-all;
        }

        .supported-formats {
            color: #666;
            font-size: 15px;
            margin-top: 15px;
        }

        .format-badge {
            display: inline-block;
            background: #2a5298;
            color: white;
            padding: 4px 12px;
            border-radius: 4px;
            margin: 0 5px;
            font-size: 13px;
            font-weight: 600;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @keyframes slideUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .error-card {
            background: linear-gradient(135deg, #fee2e2 0%, #fecaca 100%);
            border-left: 6px solid #dc2626;
            padding: 25px;
            border-radius: 10px;
            margin-top: 20px;
        }

        .error-card h3 {
            color: #dc2626;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="icon">📖</div>
            <h1>Intelligent Attack Pattern Storyteller</h1>
            <div class="subtitle">AI Reconstructs What Really Happened from Your Logs</div>
            <div class="credit">Built by Zeeshan for Hands-On</div>
        </div>

        <div class="main-card">
            <div class="upload-section" id="dropZone">
                <h2>📁 Upload Security Logs</h2>
                <p style="color: #666; margin: 15px 0; font-size: 16px;">
                    Upload authentication or network logs to discover the attack story
                </p>
                
                <div class="file-input-wrapper">
                    <label for="fileInput" class="custom-file-upload">
                        📂 Choose Log File
                    </label>
                    <input type="file" id="fileInput" accept=".txt,.json,.csv,.log" />
                </div>
                
                <div class="file-info" id="fileInfo">
                    No file selected
                </div>

                <div class="supported-formats">
                    Supported formats: 
                    <span class="format-badge">.TXT</span>
                    <span class="format-badge">.JSON</span>
                    <span class="format-badge">.CSV</span>
                    <span class="format-badge">.LOG</span>
                </div>

                <button class="analyze-btn" id="analyzeBtn" disabled>
                    🔍 Reconstruct Attack Story
                </button>
            </div>

            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p class="loading-text">🤖 AI is analyzing the logs and reconstructing the attack narrative...</p>
            </div>

            <div class="results-section" id="results">
                <!-- Results will be inserted here -->
            </div>
        </div>
    </div>

    <script>
        const fileInput = document.getElementById('fileInput');
        const fileInfo = document.getElementById('fileInfo');
        const analyzeBtn = document.getElementById('analyzeBtn');
        const loading = document.getElementById('loading');
        const results = document.getElementById('results');
        const dropZone = document.getElementById('dropZone');

        let selectedFile = null;

        fileInput.addEventListener('change', function(e) {
            if (e.target.files.length > 0) {
                selectedFile = e.target.files[0];
                const fileSize = (selectedFile.size / 1024).toFixed(2);
                fileInfo.innerHTML = `<strong>Selected:</strong> ${selectedFile.name} (${fileSize} KB)`;
                analyzeBtn.disabled = false;
            }
        });

        dropZone.addEventListener('dragover', function(e) {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });

        dropZone.addEventListener('dragleave', function(e) {
            e.preventDefault();
            dropZone.classList.remove('dragover');
        });

        dropZone.addEventListener('drop', function(e) {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const file = files[0];
                const ext = file.name.split('.').pop().toLowerCase();
                
                if (['txt', 'json', 'csv', 'log'].includes(ext)) {
                    selectedFile = file;
                    const fileSize = (selectedFile.size / 1024).toFixed(2);
                    fileInfo.innerHTML = `<strong>Selected:</strong> ${selectedFile.name} (${fileSize} KB)`;
                    analyzeBtn.disabled = false;
                } else {
                    alert('Please upload a .txt, .json, .csv, or .log file');
                }
            }
        });

        analyzeBtn.addEventListener('click', async function() {
            if (!selectedFile) return;

            const formData = new FormData();
            formData.append('file', selectedFile);

            analyzeBtn.disabled = true;
            loading.classList.add('active');
            results.classList.remove('active');
            results.innerHTML = '';

            try {
                const response = await fetch('/analyze', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.error) {
                    throw new Error(data.error);
                }

                displayResults(data);
            } catch (error) {
                results.innerHTML = `
                    <div class="error-card">
                        <h3>❌ Analysis Error</h3>
                        <p>${error.message}</p>
                    </div>
                `;
                results.classList.add('active');
            } finally {
                loading.classList.remove('active');
                analyzeBtn.disabled = false;
            }
        });

        function displayResults(data) {
            let html = '';

            // Story header
            html += `
                <div class="story-header">
                    <h2>🎬 Attack Story Reconstructed</h2>
                    <p style="opacity: 0.9; margin-top: 10px; font-size: 1.1em;">AI has analyzed the logs and reconstructed what happened</p>
                    <div class="story-meta">
                        <div class="meta-item">
                            <div class="meta-label">Total Events</div>
                            <div class="meta-value">${data.total_events || 'N/A'}</div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-label">Time Span</div>
                            <div class="meta-value">${data.time_span || 'N/A'}</div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-label">Threat Level</div>
                            <div class="meta-value">${data.threat_level || 'Unknown'}</div>
                        </div>
                        <div class="meta-item">
                            <div class="meta-label">Attack Type</div>
                            <div class="meta-value">${data.attack_type || 'Unknown'}</div>
                        </div>
                    </div>
                </div>
            `;

            // Narrative section
            if (data.narrative) {
                html += `
                    <div class="narrative-section">
                        <h3>📜 Attack Narrative</h3>
                        <div class="narrative-text">${data.narrative}</div>
                    </div>
                `;
            }

            // Timeline section
            if (data.timeline && data.timeline.length > 0) {
                html += `
                    <div class="timeline-section">
                        <h3>⏱️ Attack Timeline</h3>
                `;
                
                data.timeline.forEach(event => {
                    html += `
                        <div class="timeline-item">
                            <div class="timeline-dot"></div>
                            <div class="timeline-time">${event.time}</div>
                            <div class="timeline-event">
                                <div class="timeline-title">${event.title}</div>
                                <div class="timeline-description">${event.description}</div>
                            </div>
                        </div>
                    `;
                });

                html += `</div>`;
            }

            // Attacker objectives
            if (data.objectives && data.objectives.length > 0) {
                html += `
                    <div class="objectives-section">
                        <h3>🎯 Attacker's Likely Objectives</h3>
                        <ul class="objectives-list">
                `;
                
                data.objectives.forEach(obj => {
                    html += `<li>${obj}</li>`;
                });

                html += `
                        </ul>
                    </div>
                `;
            }

            // IoCs section
            if (data.iocs && Object.keys(data.iocs).length > 0) {
                html += `
                    <div class="iocs-section">
                        <h3>🔍 Indicators of Compromise (IoCs)</h3>
                        <div class="iocs-grid">
                `;

                for (const [type, values] of Object.entries(data.iocs)) {
                    if (values && values.length > 0) {
                        html += `
                            <div class="ioc-card">
                                <div class="ioc-type">${type}</div>
                                <div class="ioc-values">
                        `;
                        
                        values.forEach(value => {
                            html += `<div class="ioc-value">${value}</div>`;
                        });

                        html += `
                                </div>
                            </div>
                        `;
                    }
                }

                html += `
                        </div>
                    </div>
                `;
            }

            // Recommendations
            if (data.recommendations && data.recommendations.length > 0) {
                html += `
                    <div class="recommendations-section">
                        <h3>💡 Security Recommendations</h3>
                        <ul class="recommendations-list">
                `;
                
                data.recommendations.forEach(rec => {
                    html += `<li>${rec}</li>`;
                });

                html += `
                        </ul>
                    </div>
                `;
            }

            results.innerHTML = html;
            results.classList.add('active');
        }
    </script>
</body>
</html>
"""

def analyze_with_openai(log_content, file_type):
    """
    Analyze logs using OpenAI to reconstruct attack story
    """
    try:
        import openai
        
        openai.api_key = OPENAI_API_KEY
        
        # Prepare the prompt for attack story reconstruction
        prompt = f"""You are an expert cybersecurity analyst and storyteller. Analyze the following {file_type.upper()} security logs and reconstruct the complete attack story.

LOGS:
{log_content[:8000]}

Please provide your analysis in the following JSON format:
{{
    "total_events": <number of log entries analyzed>,
    "time_span": "Duration from first to last event (e.g., '2 hours 15 minutes')",
    "threat_level": "Critical|High|Medium|Low",
    "attack_type": "Type of attack detected (e.g., 'Brute Force Attack', 'SQL Injection', 'Reconnaissance')",
    "narrative": "A compelling 3-5 paragraph story explaining what happened. Write in past tense as if you're explaining to a security manager. Include who did what, when, how they did it, what they were trying to achieve, and what the outcome was. Make it engaging but factual.",
    "timeline": [
        {{
            "time": "Timestamp or relative time",
            "title": "Brief event title",
            "description": "What happened at this point"
        }}
    ],
    "objectives": [
        "First likely objective the attacker had",
        "Second objective",
        "Third objective"
    ],
    "iocs": {{
        "IP Addresses": ["ip1", "ip2"],
        "Usernames": ["user1", "user2"],
        "Domains": ["domain1"],
        "File Hashes": ["hash1"],
        "URLs": ["url1"]
    }},
    "recommendations": [
        "Specific actionable recommendation 1",
        "Specific actionable recommendation 2",
        "Specific actionable recommendation 3"
    ]
}}

IMPORTANT INSTRUCTIONS:
1. Write the narrative like a detective story - make it compelling and clear
2. Identify the attack pattern and explain it in simple terms
3. Create a chronological timeline of key events
4. Deduce what the attacker was trying to accomplish
5. Extract all relevant IoCs from the logs
6. Provide specific, actionable recommendations
7. If the logs show no attack, explain that and describe normal activity
8. Be specific with timestamps and details from the actual logs
9. Connect the dots between related events to show the attack progression"""

        # Make API call to OpenAI
        response = openai.ChatCompletion.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": "You are an expert cybersecurity analyst who excels at reconstructing attack narratives from security logs. You have deep knowledge of attack patterns, TTPs, and can tell compelling stories about security incidents."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=3000
        )
        
        # Parse the response
        analysis_text = response.choices[0].message.content
        
        # Try to extract JSON from the response
        try:
            start_idx = analysis_text.find('{')
            end_idx = analysis_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx > start_idx:
                json_str = analysis_text[start_idx:end_idx]
                analysis_data = json.loads(json_str)
            else:
                analysis_data = create_fallback_story(analysis_text, log_content)
        except json.JSONDecodeError:
            analysis_data = create_fallback_story(analysis_text, log_content)
        
        return analysis_data
        
    except Exception as e:
        return {
            "error": f"OpenAI API Error: {str(e)}. Please check your API key configuration.",
            "total_events": 0,
            "time_span": "N/A",
            "threat_level": "Unknown",
            "attack_type": "Analysis Failed",
            "narrative": "Unable to analyze logs due to API error. Please verify your OpenAI API key is correctly configured.",
            "timeline": [],
            "objectives": [],
            "iocs": {},
            "recommendations": ["Verify OpenAI API key configuration", "Check API quota and billing", "Review error logs"]
        }

def create_fallback_story(text, log_content):
    """
    Create a basic story structure when JSON parsing fails
    """
    return {
        "total_events": len(log_content.split('\n')),
        "time_span": "Analysis in progress",
        "threat_level": "Under Review",
        "attack_type": "Pattern Analysis",
        "narrative": text[:1000] if text else "Analysis completed. Review the details below.",
        "timeline": [
            {
                "time": "Analysis Start",
                "title": "Log Analysis Initiated",
                "description": "AI began analyzing the security logs"
            }
        ],
        "objectives": [
            "Determine attack pattern",
            "Identify threat actors",
            "Assess impact"
        ],
        "iocs": extract_basic_iocs(log_content),
        "recommendations": [
            "Review the analysis details above",
            "Investigate flagged events",
            "Implement security controls"
        ]
    }

def extract_basic_iocs(log_content):
    """
    Extract basic IoCs from log content using regex
    """
    iocs = {
        "IP Addresses": [],
        "Usernames": [],
        "Domains": [],
        "URLs": []
    }
    
    # Extract IP addresses
    ip_pattern = r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    ips = re.findall(ip_pattern, log_content)
    iocs["IP Addresses"] = list(set(ips))[:10]  # Limit to 10 unique IPs
    
    # Extract usernames (common patterns)
    username_patterns = [
        r'user[:\s]+([a-zA-Z0-9_\-\.]+)',
        r'username[:\s]+([a-zA-Z0-9_\-\.]+)',
        r'login[:\s]+([a-zA-Z0-9_\-\.]+)',
        r'for user ([a-zA-Z0-9_\-\.]+)'
    ]
    usernames = []
    for pattern in username_patterns:
        usernames.extend(re.findall(pattern, log_content, re.IGNORECASE))
    iocs["Usernames"] = list(set(usernames))[:10]
    
    # Extract domains
    domain_pattern = r'\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b'
    domains = re.findall(domain_pattern, log_content)
    # Filter out IPs that might match
    domains = [d for d in domains if not re.match(ip_pattern, d)]
    iocs["Domains"] = list(set(domains))[:10]
    
    # Extract URLs
    url_pattern = r'https?://[^\s<>"{}|\\^`\[\]]+'
    urls = re.findall(url_pattern, log_content)
    iocs["URLs"] = list(set(urls))[:10]
    
    # Remove empty categories
    iocs = {k: v for k, v in iocs.items() if v}
    
    return iocs

def perform_basic_analysis(log_content):
    """
    Perform basic pattern analysis without OpenAI
    """
    lines = log_content.split('\n')
    total_events = len([l for l in lines if l.strip()])
    
    # Detect attack patterns
    failed_logins = len([l for l in lines if 'failed' in l.lower() and ('login' in l.lower() or 'auth' in l.lower())])
    sql_patterns = len([l for l in lines if any(x in l.lower() for x in ['select', 'union', 'drop table', "' or", '-- '])])
    xss_patterns = len([l for l in lines if '<script>' in l.lower() or 'javascript:' in l.lower()])
    unauthorized = len([l for l in lines if 'unauthorized' in l.lower() or 'forbidden' in l.lower() or '403' in l])
    
    # Determine attack type and threat level
    attack_type = "Normal Activity"
    threat_level = "Low"
    
    if sql_patterns > 0:
        attack_type = "SQL Injection Attempt"
        threat_level = "Critical"
    elif xss_patterns > 0:
        attack_type = "Cross-Site Scripting Attempt"
        threat_level = "High"
    elif failed_logins > 5:
        attack_type = "Brute Force Attack"
        threat_level = "High"
    elif unauthorized > 3:
        attack_type = "Unauthorized Access Attempts"
        threat_level = "Medium"
    
    # Build narrative
    if attack_type == "Brute Force Attack":
        narrative = f"""A brute force attack was detected in the logs, characterized by {failed_logins} failed authentication attempts. 

The attack pattern suggests an automated tool was used to systematically guess credentials. The attacker(s) targeted multiple user accounts, attempting to gain unauthorized access to the system.

The attack appears to have originated from suspicious IP addresses that made repeated login attempts in a short time window. This behavior is inconsistent with legitimate user activity and indicates malicious intent.

The system's authentication controls appear to have successfully blocked these unauthorized access attempts, preventing the attacker from gaining entry. However, the persistence of the attack suggests a determined threat actor."""
    
    elif attack_type == "SQL Injection Attempt":
        narrative = f"""SQL injection attack patterns were detected in the logs, with {sql_patterns} suspicious database queries identified.

The attacker attempted to manipulate database queries by injecting malicious SQL code through application inputs. Common patterns like UNION statements, DROP commands, and SQL comment sequences were observed in the logs.

This type of attack could allow an adversary to bypass authentication, extract sensitive data, modify database contents, or even gain control of the database server if successful.

The presence of these patterns indicates either automated scanning tools or manual testing by an attacker familiar with SQL injection techniques. Immediate investigation and remediation are required."""
    
    elif attack_type == "Cross-Site Scripting Attempt":
        narrative = f"""Cross-site scripting (XSS) attack attempts were identified in the logs, with {xss_patterns} malicious script injection patterns detected.

The attacker tried to inject client-side scripts (typically JavaScript) into the application, likely attempting to steal user sessions, redirect users to malicious sites, or deface the application.

These injection attempts target the application's input validation and output encoding mechanisms. If successful, they could compromise user accounts and spread malware to other users of the application.

The attack patterns suggest reconnaissance phase where the attacker is probing for XSS vulnerabilities before launching a full-scale attack."""
    
    elif attack_type == "Unauthorized Access Attempts":
        narrative = f"""Multiple unauthorized access attempts were detected, with {unauthorized} attempts to access restricted resources.

The logs show repeated attempts to access administrative interfaces, configuration files, or other protected areas of the system without proper authorization. This indicates reconnaissance activity or privilege escalation attempts.

The attacker appears to be mapping the system's security boundaries, testing which resources are accessible and identifying potential entry points for further exploitation.

While these attempts were blocked by access controls, the pattern suggests a methodical approach to finding security weaknesses that could be exploited."""
    
    else:
        narrative = f"""Analysis of the logs shows relatively normal activity patterns with {total_events} events recorded.

No significant security threats were identified in the current log set. The system appears to be operating within normal parameters with expected user behaviors and system operations.

However, it's important to note that the absence of obvious threats doesn't guarantee security. Sophisticated attackers often attempt to blend in with normal traffic and may use techniques that don't leave obvious traces in standard logs.

Continued monitoring and correlation with other security data sources is recommended to maintain a comprehensive security posture."""
    
    # Build timeline
    timeline = []
    event_samples = [l for l in lines if l.strip()][:10]  # Sample events
    
    for i, event in enumerate(event_samples):
        # Extract timestamp if present
        timestamp_match = re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', event)
        time_str = timestamp_match.group(0) if timestamp_match else f"Event {i+1}"
        
        # Determine event type
        if 'failed' in event.lower():
            title = "Failed Authentication"
            desc = "Authentication attempt rejected"
        elif 'success' in event.lower():
            title = "Successful Login"
            desc = "User successfully authenticated"
        elif 'error' in event.lower():
            title = "System Error"
            desc = "Error condition detected"
        elif 'unauthorized' in event.lower():
            title = "Unauthorized Access"
            desc = "Access denied to protected resource"
        else:
            title = "System Event"
            desc = event[:100]
        
        timeline.append({
            "time": time_str,
            "title": title,
            "description": desc
        })
    
    # Determine objectives
    objectives = []
    if failed_logins > 5:
        objectives.append("Gain unauthorized access through credential guessing")
        objectives.append("Compromise user accounts")
        objectives.append("Establish persistent access to the system")
    if sql_patterns > 0:
        objectives.append("Extract sensitive data from the database")
        objectives.append("Bypass authentication mechanisms")
        objectives.append("Gain administrative privileges")
    if xss_patterns > 0:
        objectives.append("Steal user session cookies and credentials")
        objectives.append("Inject malicious content into the application")
        objectives.append("Compromise other users of the application")
    if unauthorized > 0:
        objectives.append("Map the system's security boundaries")
        objectives.append("Identify privilege escalation opportunities")
        objectives.append("Access sensitive system configurations")
    
    if not objectives:
        objectives = [
            "Routine system operations",
            "Legitimate user activities",
            "Normal business processes"
        ]
    
    return {
        "total_events": total_events,
        "time_span": "Full log duration",
        "threat_level": threat_level,
        "attack_type": attack_type,
        "narrative": narrative,
        "timeline": timeline,
        "objectives": objectives[:3],  # Limit to 3
        "iocs": extract_basic_iocs(log_content),
        "recommendations": [
            "Implement rate limiting on authentication endpoints",
            "Enable multi-factor authentication for all users",
            "Deploy Web Application Firewall (WAF) with updated rules",
            "Conduct security awareness training for users",
            "Review and strengthen input validation",
            "Enable comprehensive logging and SIEM integration",
            "Perform regular security assessments and penetration testing"
        ][:5]  # Limit to 5
    }

@app.route('/')
def index():
    """Render the main page"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/analyze', methods=['POST'])
def analyze():
    """Handle file upload and analysis"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get file extension
        filename = file.filename.lower()
        if not any(filename.endswith(ext) for ext in ['.txt', '.json', '.csv', '.log']):
            return jsonify({'error': 'Invalid file type. Please upload .txt, .json, .csv, or .log file'}), 400
        
        file_type = filename.split('.')[-1]
        
        # Read file content
        file_content = file.read().decode('utf-8', errors='ignore')
        
        # Parse based on file type
        if file_type == 'json':
            try:
                json_data = json.loads(file_content)
                log_content = json.dumps(json_data, indent=2)
            except json.JSONDecodeError:
                log_content = file_content
        
        elif file_type == 'csv':
            try:
                csv_reader = csv.DictReader(io.StringIO(file_content))
                rows = list(csv_reader)
                log_content = json.dumps(rows, indent=2)
            except:
                log_content = file_content
        
        else:  # txt or log
            log_content = file_content
        
        # Perform analysis
        if OPENAI_API_KEY and OPENAI_API_KEY != "sk-your-api-key-here":
            analysis_result = analyze_with_openai(log_content, file_type)
        else:
            # Fallback to basic analysis
            analysis_result = perform_basic_analysis(log_content)
        
        return jsonify(analysis_result)
        
    except Exception as e:
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500

if __name__ == '__main__':
    print("=" * 70)
    print("Intelligent Attack Pattern Storyteller - Built by Zeeshan for Hands-On")
    print("=" * 70)
    print("\nStarting Flask server...")
    print("\n⚠️  IMPORTANT: Update your OpenAI API key in the code!")
    print(f"Current API key starts with: {OPENAI_API_KEY[:15]}...")
    print("\n📖 This tool reconstructs attack stories from security logs")
    print("   Upload logs and watch AI tell you what really happened!")
    print("\nAccess the application at: http://127.0.0.1:5000")
    print("\nSupported file formats: .txt, .json, .csv, .log")
    print("=" * 70)
    
    app.run(debug=True, host='0.0.0.0', port=5000)