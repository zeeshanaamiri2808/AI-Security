#!/usr/bin/env python3
"""
AI Security Analyst Co-Pilot
A Flask application that helps security analysts investigate threats using AI
"""

from flask import Flask, render_template_string, request, jsonify, session
import openai
import json
import csv
import io
import os
from datetime import datetime
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# IMPORTANT: Replace with your actual OpenAI API key
OPENAI_API_KEY = "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"
openai.api_key = OPENAI_API_KEY

# HTML Template with modern UI
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🛡️ AI Security Analyst Co-Pilot</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
        }
        
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }
        
        .main-grid {
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        .card h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.5em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .upload-section {
            border: 3px dashed #667eea;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            background: #f8f9ff;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .upload-section:hover {
            background: #f0f2ff;
            border-color: #764ba2;
        }
        
        .upload-section input[type="file"] {
            display: none;
        }
        
        .upload-icon {
            font-size: 3em;
            margin-bottom: 10px;
        }
        
        .file-info {
            margin-top: 15px;
            padding: 15px;
            background: #e8f5e9;
            border-radius: 8px;
            display: none;
        }
        
        .file-info.active {
            display: block;
        }
        
        .chat-container {
            height: 500px;
            display: flex;
            flex-direction: column;
        }
        
        .messages {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        
        .message {
            margin-bottom: 15px;
            padding: 12px 18px;
            border-radius: 12px;
            max-width: 85%;
            animation: slideIn 0.3s;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .message.user {
            background: #667eea;
            color: white;
            margin-left: auto;
        }
        
        .message.assistant {
            background: white;
            border: 1px solid #e0e0e0;
        }
        
        .message.system {
            background: #fff3cd;
            border: 1px solid #ffc107;
            text-align: center;
            margin: 10px auto;
            max-width: 100%;
        }
        
        .input-group {
            display: flex;
            gap: 10px;
        }
        
        .input-group input {
            flex: 1;
            padding: 12px 18px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        
        .input-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 25px;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 600;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #764ba2;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }
        
        .quick-btn {
            padding: 10px 15px;
            background: #f8f9ff;
            border: 2px solid #667eea;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.9em;
            color: #667eea;
            font-weight: 600;
        }
        
        .quick-btn:hover {
            background: #667eea;
            color: white;
        }
        
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .action-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        
        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        .action-card h3 {
            margin-bottom: 10px;
            font-size: 1.2em;
        }
        
        .action-card p {
            font-size: 0.9em;
            opacity: 0.9;
        }
        
        .loading {
            display: none;
            text-align: center;
            padding: 10px;
        }
        
        .loading.active {
            display: block;
        }
        
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-top: 15px;
        }
        
        .stat-box {
            background: #f8f9ff;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        
        .stat-box .number {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }
        
        .stat-box .label {
            font-size: 0.9em;
            color: #6c757d;
            margin-top: 5px;
        }
        
        @media (max-width: 1024px) {
            .main-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛡️ AI Security Analyst Co-Pilot</h1>
            <p>Upload security logs • Ask questions • Get AI-powered insights</p>
        </div>
        
        <div class="main-grid">
            <!-- Left Column: Upload & Actions -->
            <div>
                <div class="card">
                    <h2>📁 Upload Security Data</h2>
                    <div class="upload-section" onclick="document.getElementById('fileInput').click()">
                        <div class="upload-icon">📤</div>
                        <h3>Click to Upload</h3>
                        <p>Supports: .txt, .json, .csv</p>
                        <input type="file" id="fileInput" accept=".txt,.json,.csv">
                    </div>
                    <div id="fileInfo" class="file-info">
                        <strong>📄 File loaded:</strong> <span id="fileName"></span><br>
                        <strong>📊 Size:</strong> <span id="fileSize"></span><br>
                        <strong>📝 Lines/Records:</strong> <span id="fileLines"></span>
                    </div>
                </div>
                
                <div class="card" style="margin-top: 20px;">
                    <h2>⚡ Quick Actions</h2>
                    <div class="actions-grid">
                        <div class="action-card" onclick="askQuestion('Analyze this data and summarize all security incidents')">
                            <h3>🔍</h3>
                            <h3>Analyze Data</h3>
                            <p>Get security overview</p>
                        </div>
                        <div class="action-card" onclick="askQuestion('Generate a detailed investigation report with timeline and recommendations')">
                            <h3>📋</h3>
                            <h3>Generate Report</h3>
                            <p>Create investigation report</p>
                        </div>
                        <div class="action-card" onclick="askQuestion('What are the critical threats? Prioritize by severity')">
                            <h3>⚠️</h3>
                            <h3>Find Threats</h3>
                            <p>Identify critical issues</p>
                        </div>
                        <div class="action-card" onclick="askQuestion('Create an executive summary for leadership (non-technical)')">
                            <h3>👔</h3>
                            <h3>Executive Summary</h3>
                            <p>For leadership</p>
                        </div>
                        <div class="action-card" onclick="askQuestion('What are the recommended next steps for this investigation?')">
                            <h3>🎯</h3>
                            <h3>Next Steps</h3>
                            <p>Get recommendations</p>
                        </div>
                        <div class="action-card" onclick="askQuestion('Identify the attack timeline and affected systems')">
                            <h3>⏱️</h3>
                            <h3>Timeline</h3>
                            <p>Track events</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right Column: Chat Interface -->
            <div class="card">
                <h2>💬 AI Security Assistant</h2>
                <div class="chat-container">
                    <div id="messages" class="messages">
                        <div class="message system">
                            👋 Welcome! Upload your security data and start asking questions.
                        </div>
                    </div>
                    <div class="quick-actions">
                        <button class="quick-btn" onclick="askQuestion('What happened?')">What happened?</button>
                        <button class="quick-btn" onclick="askQuestion('Who did this?')">Who did this?</button>
                        <button class="quick-btn" onclick="askQuestion('Is this bad?')">Is this bad?</button>
                        <button class="quick-btn" onclick="askQuestion('Show me suspicious activities')">Suspicious activities</button>
                    </div>
                    <div class="loading" id="loading">
                        <div class="spinner"></div>
                    </div>
                    <div class="input-group">
                        <input type="text" id="userInput" placeholder="Ask about your security data..." onkeypress="handleKeyPress(event)">
                        <button class="btn btn-primary" onclick="sendMessage()">Send</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        let uploadedData = null;
        
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = function(event) {
                const content = event.target.result;
                uploadedData = {
                    filename: file.name,
                    content: content,
                    size: file.size
                };
                
                // Update file info
                document.getElementById('fileName').textContent = file.name;
                document.getElementById('fileSize').textContent = formatBytes(file.size);
                
                // Count lines/records
                const lines = content.split('\\n').length;
                document.getElementById('fileLines').textContent = lines;
                document.getElementById('fileInfo').classList.add('active');
                
                // Upload to server
                uploadFile(file);
            };
            reader.readAsText(file);
        });
        
        function formatBytes(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }
        
        async function uploadFile(file) {
            const formData = new FormData();
            formData.append('file', file);
            
            try {
                const response = await fetch('/upload', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.status === 'success') {
                    addMessage('system', `✅ File uploaded successfully! ${data.records_count} records loaded. You can now ask questions.`);
                }
            } catch (error) {
                addMessage('system', '❌ Error uploading file. Please try again.');
            }
        }
        
        function addMessage(type, content) {
            const messagesDiv = document.getElementById('messages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}`;
            messageDiv.textContent = content;
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }
        
        async function sendMessage() {
            const input = document.getElementById('userInput');
            const question = input.value.trim();
            
            if (!question) return;
            
            addMessage('user', question);
            input.value = '';
            
            document.getElementById('loading').classList.add('active');
            
            try {
                const response = await fetch('/chat', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ question: question })
                });
                
                const data = await response.json();
                document.getElementById('loading').classList.remove('active');
                
                if (data.status === 'success') {
                    addMessage('assistant', data.response);
                } else {
                    addMessage('system', '❌ Error: ' + data.message);
                }
            } catch (error) {
                document.getElementById('loading').classList.remove('active');
                addMessage('system', '❌ Error communicating with AI. Please try again.');
            }
        }
        
        function askQuestion(question) {
            document.getElementById('userInput').value = question;
            sendMessage();
        }
        
        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        }
    </script>
</body>
</html>
"""

class SecurityDataProcessor:
    """Process and analyze security data"""
    
    @staticmethod
    def parse_file(content, filename):
        """Parse uploaded file based on extension"""
        ext = filename.lower().split('.')[-1]
        
        if ext == 'json':
            try:
                data = json.loads(content)
                return SecurityDataProcessor.format_json_data(data)
            except json.JSONDecodeError:
                return content
        
        elif ext == 'csv':
            try:
                csv_reader = csv.DictReader(io.StringIO(content))
                rows = list(csv_reader)
                return SecurityDataProcessor.format_csv_data(rows)
            except Exception:
                return content
        
        else:  # txt or unknown
            return content
    
    @staticmethod
    def format_json_data(data):
        """Format JSON data for better readability"""
        if isinstance(data, list):
            return json.dumps(data, indent=2)
        elif isinstance(data, dict):
            return json.dumps(data, indent=2)
        return str(data)
    
    @staticmethod
    def format_csv_data(rows):
        """Format CSV data"""
        output = []
        for i, row in enumerate(rows[:100]):  # Limit to 100 rows
            output.append(f"Record {i+1}:")
            for key, value in row.items():
                output.append(f"  {key}: {value}")
            output.append("")
        return "\n".join(output)
    
    @staticmethod
    def count_records(content, filename):
        """Count records in the file"""
        ext = filename.lower().split('.')[-1]
        
        if ext == 'json':
            try:
                data = json.loads(content)
                if isinstance(data, list):
                    return len(data)
                elif isinstance(data, dict):
                    return 1
            except:
                pass
        
        elif ext == 'csv':
            try:
                return len(list(csv.DictReader(io.StringIO(content))))
            except:
                pass
        
        # For txt or if parsing fails
        return len(content.split('\n'))

@app.route('/')
def index():
    """Render main page"""
    session['conversation'] = []
    session['uploaded_data'] = None
    return render_template_string(HTML_TEMPLATE)

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload"""
    try:
        if 'file' not in request.files:
            return jsonify({'status': 'error', 'message': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'status': 'error', 'message': 'No file selected'}), 400
        
        # Read file content
        content = file.read().decode('utf-8')
        
        # Process the file
        processed_data = SecurityDataProcessor.parse_file(content, file.filename)
        records_count = SecurityDataProcessor.count_records(content, file.filename)
        
        # Store in session
        session['uploaded_data'] = {
            'filename': file.filename,
            'content': processed_data,
            'raw_content': content,
            'records_count': records_count
        }
        
        # Initialize conversation with system context
        session['conversation'] = [{
            'role': 'system',
            'content': f"""You are an expert security analyst AI assistant. You help analyze security logs, 
alerts, and threat data. Be concise, accurate, and actionable in your responses.

The user has uploaded a file: {file.filename} with {records_count} records.

When analyzing data:
- Identify security incidents, threats, and anomalies
- Provide clear timelines when relevant
- Suggest specific next steps
- Highlight critical issues
- Use security terminology appropriately
- Format responses clearly with bullet points when listing items

Current data loaded:
{processed_data[:2000]}... (truncated for context)
"""
        }]
        
        return jsonify({
            'status': 'success',
            'filename': file.filename,
            'records_count': records_count
        })
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.json
        question = data.get('question', '')
        
        if not question:
            return jsonify({'status': 'error', 'message': 'No question provided'}), 400
        
        # Check if data is uploaded
        if 'uploaded_data' not in session or not session['uploaded_data']:
            return jsonify({
                'status': 'success',
                'response': '⚠️ Please upload a security data file first before asking questions.'
            })
        
        # Get conversation history
        conversation = session.get('conversation', [])
        
        # Add user message
        conversation.append({
            'role': 'user',
            'content': question
        })
        
        # Call OpenAI API
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",  # Use gpt-3.5-turbo for faster/cheaper responses
                messages=conversation,
                max_tokens=1500,
                temperature=0.7
            )
            
            assistant_message = response.choices[0].message.content
            
            # Add assistant response to conversation
            conversation.append({
                'role': 'assistant',
                'content': assistant_message
            })
            
            # Update session
            session['conversation'] = conversation
            
            return jsonify({
                'status': 'success',
                'response': assistant_message
            })
        
        except openai.error.AuthenticationError:
            return jsonify({
                'status': 'error',
                'message': '🔑 Invalid OpenAI API key. Please update OPENAI_API_KEY in the code.'
            }), 401
        
        except openai.error.RateLimitError:
            return jsonify({
                'status': 'error',
                'message': '⏱️ Rate limit exceeded. Please try again in a moment.'
            }), 429
        
        except Exception as e:
            return jsonify({
                'status': 'error',
                'message': f'OpenAI API Error: {str(e)}'
            }), 500
    
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🛡️  AI SECURITY ANALYST CO-PILOT")
    print("=" * 60)
    print("\n📝 SETUP INSTRUCTIONS:")
    print("1. Update OPENAI_API_KEY variable in the code")
    print("2. Install required packages:")
    print("   pip install flask openai")
    print("\n🚀 Starting server...")
    print("🌐 Open your browser to: http://127.0.0.1:5000")
    print("\n⚠️  Make sure to replace 'sk-your-openai-api-key-here' with your actual OpenAI API key!")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)