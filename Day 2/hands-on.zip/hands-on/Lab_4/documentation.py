"""
Security Documentation Generator - Single File Version
AI-Powered Security Documentation Creation Tool
"""

from flask import Flask, request, jsonify, send_file, render_template_string
import json
from datetime import datetime
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from io import BytesIO

# Handle both old and new OpenAI package versions
try:
    from openai import OpenAI
    USE_NEW_API = True
except ImportError:
    import openai
    USE_NEW_API = False

app = Flask(__name__)

# ============================================================================
# CONFIGURATION - ADD YOUR OPENAI API KEY HERE
# ============================================================================
OPENAI_API_KEY = "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"  # ← REPLACE WITH YOUR ACTUAL KEY

# Initialize OpenAI client based on version
if USE_NEW_API:
    client = OpenAI(api_key=OPENAI_API_KEY)
else:
    openai.api_key = OPENAI_API_KEY

# ============================================================================
# DOCUMENT GENERATION PROMPTS
# ============================================================================
PROMPTS = {
    "runbook": """Generate a detailed security runbook based on the following information:
{input_data}

Create a comprehensive runbook that includes:
1. Purpose and Scope
2. Prerequisites and Access Requirements
3. Step-by-step Procedures (detailed and actionable)
4. Verification Steps
5. Rollback Procedures
6. Troubleshooting Guide
7. Contact Information and Escalation Path

Format the output in a clear, professional manner with proper sections and subsections.""",

    "playbook": """Generate a detailed security incident playbook based on the following information:
{input_data}

Create a comprehensive playbook that includes:
1. Incident Overview and Scenarios
2. Roles and Responsibilities
3. Detection and Analysis Steps
4. Containment Procedures
5. Eradication Steps
6. Recovery Procedures
7. Post-Incident Activities
8. Communication Plan

Format the output in a clear, professional manner with proper sections and subsections.""",

    "incident_response": """Generate a detailed incident response procedure based on the following information:
{input_data}

Create a comprehensive incident response procedure that includes:
1. Incident Classification and Severity Levels
2. Initial Response Steps
3. Investigation Procedures
4. Containment Strategies
5. Evidence Collection and Preservation
6. Communication Protocol
7. Resolution and Recovery
8. Lessons Learned Process

Format the output in a clear, professional manner with proper sections and subsections.""",

    "architecture": """Generate detailed security architecture documentation based on the following information:
{input_data}

Create comprehensive architecture documentation that includes:
1. Architecture Overview
2. Security Zones and Network Segmentation
3. Component Descriptions and Security Features
4. Data Flow Diagrams (describe in text)
5. Security Controls by Layer
6. Authentication and Authorization Mechanisms
7. Encryption and Key Management
8. Monitoring and Logging Architecture
9. Threat Model and Mitigations

Format the output in a clear, professional manner with proper sections and subsections.""",

    "compliance": """Generate a detailed compliance checklist based on the following information:
{input_data}

Create a comprehensive compliance checklist that includes:
1. Compliance Framework Overview
2. Control Categories
3. Detailed Checklist Items (with descriptions)
4. Implementation Guidance
5. Evidence Requirements
6. Testing Procedures
7. Reporting Requirements
8. Remediation Guidance

Format the output in a clear, professional manner with proper sections and subsections."""
}

# ============================================================================
# SAMPLE INPUTS FOR EACH DOCUMENT TYPE
# ============================================================================
SAMPLE_INPUTS = {
    "runbook": """Tool: Splunk Enterprise Security
Purpose: Weekly threat hunting queries execution
Team: Threat Hunting Team
Schedule: Every Monday 9 AM EST
Environment: Production SIEM
Required Access: Splunk Power User role
Integration: ServiceNow for ticket creation
Expected Duration: 2-3 hours
Escalation: SOC Manager if critical findings""",

    "playbook": """Incident Type: Ransomware Attack
Affected Systems: Windows endpoints, file servers
Detection Methods: EDR alerts, user reports, AV detection
Initial Indicators: File encryption, ransom notes, suspicious processes
Critical Assets: Customer database, financial records
Recovery: Backup restoration from isolated backup system
Stakeholders: CISO, Legal, PR, IT Operations
Communication: Internal via Teams, External via approved channels""",

    "incident_response": """Organization: Financial Services Company (500 employees)
Environment: Hybrid cloud (AWS + On-premise)
Critical Systems: Core banking app, customer portal, internal systems
Security Tools: CrowdStrike EDR, Palo Alto firewalls, Splunk SIEM
Compliance: PCI-DSS, SOC 2, GDPR
Incident Types: Data breach, DDoS, malware, insider threat
Team Structure: SOC (5), Incident Response (3), Management
SLAs: Critical - 15 min, High - 1 hour, Medium - 4 hours""",

    "architecture": """System: Cloud-Native E-commerce Platform
Infrastructure: AWS (multi-region)
Components:
- Frontend: React app on CloudFront/S3
- API: Microservices on EKS (Kubernetes)
- Database: RDS PostgreSQL, DynamoDB
- Authentication: Cognito + OAuth 2.0
- Payment: Stripe integration
Security Requirements:
- PCI-DSS compliance for payment data
- Zero-trust network architecture
- Data encryption at rest and in transit
- WAF for web application protection
- DDoS protection
- SIEM integration for logging""",

    "compliance": """Framework: SOC 2 Type II
Organization: SaaS Company
Scope: Customer data processing, cloud infrastructure
Key Controls:
- Access management (MFA, RBAC)
- Data encryption (AES-256)
- Network security (firewalls, IDS/IPS)
- Logging and monitoring (SIEM)
- Incident response procedures
- Vendor management
- Change management
- Business continuity
Audit Period: Annual
Previous Findings: 3 medium-risk items from last audit"""
}

# ============================================================================
# HTML TEMPLATE (EMBEDDED)
# ============================================================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Documentation Generator</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        header {
            text-align: center;
            color: white;
            margin-bottom: 30px;
            animation: fadeInDown 0.6s ease-out;
        }

        header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .main-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            animation: fadeInUp 0.6s ease-out;
        }

        .panel {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .panel h2 {
            color: #667eea;
            margin-bottom: 20px;
            font-size: 1.5em;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .icon {
            font-size: 1.2em;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        select, textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            font-family: inherit;
            transition: all 0.3s ease;
        }

        select:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        textarea {
            resize: vertical;
            min-height: 200px;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 14px 30px;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }

        .btn:active {
            transform: translateY(0);
        }

        .btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        .output-content {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            min-height: 400px;
            max-height: 600px;
            overflow-y: auto;
            white-space: pre-wrap;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            line-height: 1.6;
            border: 2px solid #e0e0e0;
        }

        .output-content.empty {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-style: italic;
        }

        .export-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 15px;
        }

        .btn-export {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-export:hover {
            background: #667eea;
            color: white;
        }

        .btn-export:disabled {
            opacity: 0.4;
            cursor: not-allowed;
        }

        .loading {
            text-align: center;
            padding: 20px;
            color: #667eea;
        }

        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .info-box {
            background: #e3f2fd;
            border-left: 4px solid #2196f3;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 0.9em;
        }

        .info-box strong {
            color: #1976d2;
        }

        .sample-data {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
            font-size: 0.85em;
        }

        .sample-data h4 {
            color: #856404;
            margin-bottom: 8px;
        }

        @media (max-width: 968px) {
            .main-content {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🛡️ Security Documentation Generator</h1>
            <p>AI-Powered Security Documentation Creation Tool</p>
        </header>

        <div class="main-content">
            <!-- Input Panel -->
            <div class="panel">
                <h2><span class="icon">📝</span> Input Configuration</h2>
                
                <div class="info-box">
                    <strong>How to use:</strong> Select the document type, provide your security context/requirements, and click Generate. The AI will create comprehensive documentation.
                </div>

                <form id="docForm">
                    <div class="form-group">
                        <label for="docType">Document Type:</label>
                        <select id="docType" required>
                            <option value="">-- Select Document Type --</option>
                            <option value="runbook">Security Runbook</option>
                            <option value="playbook">Incident Playbook</option>
                            <option value="incident_response">Incident Response Procedure</option>
                            <option value="architecture">Security Architecture</option>
                            <option value="compliance">Compliance Checklist</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="inputData">Security Context/Requirements:</label>
                        <textarea 
                            id="inputData" 
                            placeholder="Describe your security requirements, tools, configurations, or specific scenarios...

Example for Runbook:
- Tool: AWS Security Hub
- Purpose: Daily security findings review
- Team: SOC Team
- Integration: Slack, Jira

See sample inputs below for more examples."
                            required
                        ></textarea>
                    </div>

                    <div class="sample-data" id="sampleData">
                        <h4>💡 Sample Input for Selected Type:</h4>
                        <p id="sampleText">Select a document type to see sample input</p>
                    </div>

                    <button type="submit" class="btn" id="generateBtn">
                        🚀 Generate Documentation
                    </button>
                </form>
            </div>

            <!-- Output Panel -->
            <div class="panel">
                <h2><span class="icon">📄</span> Generated Documentation</h2>
                
                <div id="output" class="output-content empty">
                    Generated documentation will appear here...
                </div>

                <div class="export-buttons">
                    <button class="btn-export" id="exportDocx" disabled>
                        📥 Export as DOCX
                    </button>
                    <button class="btn-export" id="exportMd" disabled>
                        📥 Export as Markdown
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const sampleInputs = {{ sample_inputs | tojson }};

        const docTypeSelect = document.getElementById('docType');
        const sampleText = document.getElementById('sampleText');
        const docForm = document.getElementById('docForm');
        const generateBtn = document.getElementById('generateBtn');
        const output = document.getElementById('output');
        const exportDocx = document.getElementById('exportDocx');
        const exportMd = document.getElementById('exportMd');
        const inputData = document.getElementById('inputData');

        let generatedContent = '';
        let currentDocType = '';

        // Update sample input when document type changes
        docTypeSelect.addEventListener('change', function() {
            const type = this.value;
            if (type && sampleInputs[type]) {
                sampleText.textContent = sampleInputs[type];
            } else {
                sampleText.textContent = 'Select a document type to see sample input';
            }
        });

        // Generate documentation
        docForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const type = docTypeSelect.value;
            const input = inputData.value.trim();

            if (!type || !input) {
                alert('Please fill in all fields');
                return;
            }

            // Disable button and show loading
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generating...';
            output.innerHTML = '<div class="loading"><div class="spinner"></div><p>Generating your security documentation...</p></div>';
            output.classList.remove('empty');

            try {
                const response = await fetch('/generate', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        type: type,
                        input_data: input
                    })
                });

                const data = await response.json();

                if (data.success) {
                    generatedContent = data.content;
                    currentDocType = type;
                    output.textContent = data.content;
                    exportDocx.disabled = false;
                    exportMd.disabled = false;
                } else {
                    output.textContent = 'Error: ' + (data.error || 'Failed to generate documentation');
                    output.classList.add('empty');
                }
            } catch (error) {
                output.textContent = 'Error: ' + error.message;
                output.classList.add('empty');
            } finally {
                generateBtn.disabled = false;
                generateBtn.textContent = '🚀 Generate Documentation';
            }
        });

        // Export as DOCX
        exportDocx.addEventListener('click', async function() {
            if (!generatedContent) return;

            try {
                const response = await fetch('/export/docx', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        content: generatedContent,
                        type: currentDocType
                    })
                });

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `security_doc_${currentDocType}_${Date.now()}.docx`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } catch (error) {
                alert('Error exporting DOCX: ' + error.message);
            }
        });

        // Export as Markdown
        exportMd.addEventListener('click', async function() {
            if (!generatedContent) return;

            try {
                const response = await fetch('/export/markdown', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        content: generatedContent,
                        type: currentDocType
                    })
                });

                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `security_doc_${currentDocType}_${Date.now()}.md`;
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } catch (error) {
                alert('Error exporting Markdown: ' + error.message);
            }
        });
    </script>
</body>
</html>
"""

# ============================================================================
# OPENAI GENERATION FUNCTION
# ============================================================================
def generate_with_openai(prompt):
    """Generate content using OpenAI API (handles both old and new versions)"""
    try:
        if USE_NEW_API:
            # New API (openai >= 1.0.0)
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a senior security engineer and technical writer specializing in creating clear, comprehensive security documentation. Generate professional, actionable documentation that follows industry best practices."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2500
            )
            return response.choices[0].message.content
        else:
            # Old API (openai < 1.0.0)
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You are a senior security engineer and technical writer specializing in creating clear, comprehensive security documentation. Generate professional, actionable documentation that follows industry best practices."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2500
            )
            return response.choices[0].message['content']
    except Exception as e:
        raise Exception(f"OpenAI API Error: {str(e)}")

# ============================================================================
# FLASK ROUTES
# ============================================================================
@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, sample_inputs=SAMPLE_INPUTS)

@app.route('/generate', methods=['POST'])
def generate_documentation():
    try:
        data = request.json
        doc_type = data.get('type')
        input_data = data.get('input_data')
        
        if not doc_type or not input_data:
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Get the appropriate prompt
        prompt_template = PROMPTS.get(doc_type)
        if not prompt_template:
            return jsonify({'error': 'Invalid document type'}), 400
        
        # Generate documentation using OpenAI
        prompt = prompt_template.format(input_data=input_data)
        content = generate_with_openai(prompt)
        
        return jsonify({
            'success': True,
            'content': content,
            'timestamp': datetime.now().isoformat()
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/docx', methods=['POST'])
def export_docx():
    try:
        data = request.json
        content = data.get('content')
        doc_type = data.get('type', 'document')
        
        # Create Word document
        doc = Document()
        
        # Add title
        title = doc.add_heading('Security Documentation', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add metadata
        doc.add_paragraph(f'Document Type: {doc_type.replace("_", " ").title()}')
        doc.add_paragraph(f'Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
        doc.add_paragraph('Generated by: Security Documentation Generator')
        doc.add_paragraph('')
        
        # Add content
        lines = content.split('\n')
        for line in lines:
            line = line.strip()
            if not line:
                doc.add_paragraph('')
            elif line.startswith('# '):
                doc.add_heading(line[2:], level=1)
            elif line.startswith('## '):
                doc.add_heading(line[3:], level=2)
            elif line.startswith('### '):
                doc.add_heading(line[4:], level=3)
            elif line.startswith('- ') or line.startswith('* '):
                doc.add_paragraph(line[2:], style='List Bullet')
            elif line and line[0].isdigit() and len(line) > 2 and line[1:3] == '. ':
                doc.add_paragraph(line[3:], style='List Number')
            else:
                doc.add_paragraph(line)
        
        # Save to BytesIO
        file_stream = BytesIO()
        doc.save(file_stream)
        file_stream.seek(0)
        
        filename = f'security_doc_{doc_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.docx'
        
        return send_file(
            file_stream,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            as_attachment=True,
            download_name=filename
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/export/markdown', methods=['POST'])
def export_markdown():
    try:
        data = request.json
        content = data.get('content')
        doc_type = data.get('type', 'document')
        
        # Add metadata header
        markdown_content = f"""# Security Documentation

**Document Type:** {doc_type.replace("_", " ").title()}  
**Generated:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}  
**Generated by:** Security Documentation Generator

---

{content}
"""
        
        # Convert to BytesIO
        file_stream = BytesIO()
        file_stream.write(markdown_content.encode('utf-8'))
        file_stream.seek(0)
        
        filename = f'security_doc_{doc_type}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.md'
        
        return send_file(
            file_stream,
            mimetype='text/markdown',
            as_attachment=True,
            download_name=filename
        )
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================
if __name__ == '__main__':
    print("\n" + "="*70)
    print("🛡️  SECURITY DOCUMENTATION GENERATOR")
    print("="*70)
    print(f"OpenAI API Version: {'New (1.x)' if USE_NEW_API else 'Legacy (0.x)'}")
    
    if OPENAI_API_KEY == "sk-proj-your-api-key-here":
        print("⚠️  WARNING: Please add your OpenAI API key on line 32!")
        print("    Edit this file and replace 'sk-proj-your-api-key-here'")
    else:
        print("✅ API Key: Configured")
    
    print("="*70)
    print("\n🚀 Starting Flask server...")
    print("📱 Open in browser: http://localhost:5000")
    print("\n💡 Sample inputs are embedded in the interface")
    print("="*70 + "\n")
    
    app.run(debug=True, port=5000, host='0.0.0.0')