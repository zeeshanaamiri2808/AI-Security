"""
GenAI IoT Security Lab — Printer Attack Simulation
Flask + OpenAI GPT-4 Demo
"""

from flask import Flask, render_template, jsonify, request
from openai import OpenAI
import datetime
import random
import json
import time

app = Flask(__name__)

# ── HARDCODED FOR LAB DEMO ──────────────────────────────────────────────────
OPENAI_API_KEY = "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"   # <-- replace with your key
client = OpenAI(api_key=OPENAI_API_KEY)
# ────────────────────────────────────────────────────────────────────────────

# ── SIMULATED PRINTER STATE ──────────────────────────────────────────────────
printer_state = {
    "ip": "192.168.1.105",
    "model": "HP LaserJet Pro M404n",
    "firmware": "v2.7.1 (2021-03-15)",
    "status": "ONLINE",
    "open_ports": [80, 443, 9100, 631, 161],
    "services": {"80": "HTTP Web UI", "443": "HTTPS Web UI", "9100": "RAW Print", "631": "IPP", "161": "SNMP"},
    "admin_user": "admin",
    "admin_pass": "admin",          # default creds — never changed
    "job_log": [],
    "alert_log": [],
    "blocked_ips": [],
    "snmp_community": "public",     # default SNMP community string
    "web_ui_session": None,
}

# ── ATTACK DEFINITIONS ───────────────────────────────────────────────────────
ATTACKS = {
    "port_scan": {
        "name": "Port Scan & Service Enumeration",
        "category": "Reconnaissance",
        "attacker_ip": "10.0.0.66",
        "severity": "MEDIUM",
        "icon": "🔍",
        "description": "Attacker scans all TCP ports on the printer to discover running services and fingerprint the device model/firmware.",
        "simulated_payload": {
            "type": "TCP_SYN_SCAN",
            "source_ip": "10.0.0.66",
            "target_ip": "192.168.1.105",
            "ports_scanned": "1-65535",
            "scan_rate": "1000 pkts/sec",
            "tool": "nmap -sS -sV -O 192.168.1.105",
            "discovered": {
                "open_ports": [80, 443, 9100, 631, 161],
                "os_guess": "Linux 3.x (HP embedded)",
                "device_fingerprint": "HP LaserJet Pro M404n"
            }
        }
    },
    "default_creds": {
        "name": "Default Credential Exploitation",
        "category": "Authentication Attack",
        "attacker_ip": "10.0.0.66",
        "severity": "CRITICAL",
        "icon": "🔑",
        "description": "Attacker tries factory-default admin credentials (admin/admin) on the printer web management interface to gain full administrative control.",
        "simulated_payload": {
            "type": "HTTP_AUTH_BRUTE",
            "source_ip": "10.0.0.66",
            "target": "http://192.168.1.105/hp/device/SignIn",
            "method": "POST",
            "attempts": [
                {"user": "admin", "pass": "admin", "result": "SUCCESS ✓"},
                {"user": "admin", "pass": "password", "result": "FAIL"},
                {"user": "root", "pass": "root", "result": "FAIL"},
            ],
            "session_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.ADMIN",
            "access_level": "FULL ADMINISTRATOR"
        }
    },
    "pjl_injection": {
        "name": "PJL Command Injection",
        "category": "Protocol Exploitation",
        "attacker_ip": "10.0.0.66",
        "severity": "CRITICAL",
        "icon": "💉",
        "description": "Attacker sends malicious Printer Job Language commands directly to port 9100 to read the printer filesystem, extract stored credentials, and modify device settings.",
        "simulated_payload": {
            "type": "PJL_RAW_SOCKET",
            "source_ip": "10.0.0.66",
            "target": "192.168.1.105:9100",
            "protocol": "RAW TCP",
            "malicious_commands": [
                "@PJL INFO ID",
                "@PJL FSQUERY FORMAT:BINARY NAME=\"0:\\..\\..\\etc\\passwd\"",
                "@PJL FSDOWNLOAD FORMAT:BINARY NAME=\"0:\\passwords.txt\"",
                "@PJL SET PASSWORD=HACKED123",
                "@PJL RESET"
            ],
            "data_exfiltrated": "printer_passwords.txt (2.1KB)",
            "impact": "Credentials stolen, admin password changed"
        }
    },
    "print_flood": {
        "name": "Print Job Flood (DoS)",
        "category": "Denial of Service",
        "attacker_ip": "10.0.0.44",
        "severity": "HIGH",
        "icon": "🌊",
        "description": "Attacker floods the printer's job queue with thousands of large print jobs, causing a denial of service that prevents legitimate users from printing.",
        "simulated_payload": {
            "type": "IPP_FLOOD",
            "source_ip": "10.0.0.44",
            "target": "192.168.1.105:631",
            "protocol": "IPP",
            "jobs_submitted": 8420,
            "job_size_avg": "48MB (A3 full-color PDF)",
            "rate": "312 jobs/second",
            "queue_depth": "8420/50 MAX",
            "printer_response": "503 Service Unavailable",
            "impact": "Printer offline for 47 minutes"
        }
    },
    "snmp_harvest": {
        "name": "SNMP Community String Harvest",
        "category": "Information Disclosure",
        "attacker_ip": "10.0.0.66",
        "severity": "HIGH",
        "icon": "📡",
        "description": "Attacker exploits the default SNMP community string 'public' to enumerate all device information including job logs, user data, network configuration, and stored document metadata.",
        "simulated_payload": {
            "type": "SNMP_WALK",
            "source_ip": "10.0.0.66",
            "target": "192.168.1.105:161",
            "protocol": "UDP/SNMP v1",
            "community_string": "public",
            "oids_harvested": 1847,
            "data_extracted": {
                "job_history": "Last 500 print jobs (filename, sender, timestamp)",
                "network_config": "IP, gateway, DNS, VLAN assignments",
                "user_accounts": "4 local accounts with hashed passwords",
                "document_store": "38 retained documents (HR, Finance, Legal)"
            }
        }
    },
    "firmware_tamper": {
        "name": "Malicious Firmware Injection",
        "category": "Supply Chain / Persistence",
        "attacker_ip": "10.0.0.99",
        "severity": "CRITICAL",
        "icon": "☠️",
        "description": "Attacker intercepts an unsigned firmware update request and replaces the legitimate firmware with a backdoored version that creates a persistent reverse shell.",
        "simulated_payload": {
            "type": "FIRMWARE_MITM",
            "source_ip": "10.0.0.99",
            "intercept_method": "ARP Spoofing → MITM",
            "original_firmware": "HP_LJProM404n_v2.7.2_official.bin (SHA256: a3f9b2...)",
            "injected_firmware": "HP_LJProM404n_v2.7.2_BACKDOOR.bin (SHA256: CHANGED)",
            "signature_check": "DISABLED — no firmware signing on this model",
            "backdoor_payload": "Reverse shell on TCP/4444 → 10.0.0.99",
            "persistence": "Survives factory reset, embedded in bootloader"
        }
    },
    "data_exfil": {
        "name": "Document Store Exfiltration",
        "category": "Data Theft",
        "attacker_ip": "10.0.0.66",
        "severity": "CRITICAL",
        "icon": "📂",
        "description": "After gaining admin access, attacker accesses the printer's internal hard drive to download all retained print jobs — including confidential HR, finance, and legal documents.",
        "simulated_payload": {
            "type": "HTTP_DATA_THEFT",
            "source_ip": "10.0.0.66",
            "session": "AUTHENTICATED (stolen admin session)",
            "endpoint": "GET /hp/device/JobLog?action=download&format=ALL",
            "documents_stolen": [
                "Q3_Payroll_Report_2024.pdf (CEO, CFO, all salaries)",
                "MnA_Target_Valuation_CONFIDENTIAL.pdf",
                "HR_Termination_List_Oct2024.pdf",
                "Board_Minutes_Strategy_2025.pdf",
                "Contract_Vendor_NDA_Signed.pdf"
            ],
            "total_size": "847MB",
            "exfil_channel": "HTTPS POST → attacker C2 server"
        }
    },
    "postscript_loop": {
        "name": "Malicious PostScript Infinite Loop",
        "category": "Denial of Service",
        "attacker_ip": "10.0.0.44",
        "severity": "MEDIUM",
        "icon": "🔄",
        "description": "Attacker sends a print job containing a PostScript infinite loop that consumes 100% of the printer's CPU, locking the device until it is physically power-cycled.",
        "simulated_payload": {
            "type": "POSTSCRIPT_EXPLOIT",
            "source_ip": "10.0.0.44",
            "target": "192.168.1.105:9100",
            "protocol": "RAW/PostScript",
            "malicious_code": "%!PS\n{ dup mul } dup 256 array copy cvx exec\n%%EOF",
            "effect": "CPU: 100%, Memory: 98%, Print queue: FROZEN",
            "recovery": "Physical power cycle required (2-3 min downtime)"
        }
    }
}


def get_timestamp():
    return datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]


def analyze_with_genai(attack_key, attack_data, printer_info):
    """Send attack details to OpenAI GPT-4 for analysis and response recommendation."""
    
    system_prompt = """You are GenAI-Shield, an advanced AI cybersecurity system protecting IoT devices — specifically network printers — in real time.

You monitor all network traffic, print jobs, authentication events, and system logs for the printer fleet. When an attack is detected, you must:

1. ANALYZE the attack pattern and identify exactly what is happening
2. ASSESS the severity and potential impact
3. PROVIDE immediate automated response actions (what you are doing RIGHT NOW)
4. GIVE alert details for the SOC team
5. RECOMMEND remediation steps

Your response MUST be structured as valid JSON with these exact fields:
{
  "threat_confirmed": true/false,
  "threat_name": "...",
  "severity": "CRITICAL/HIGH/MEDIUM/LOW",
  "confidence": "percentage 0-100",
  "attack_vector": "...",
  "what_is_happening": "2-3 sentence plain English explanation",
  "impact_if_unchecked": "...",
  "automated_actions": ["action1", "action2", "action3"],
  "alert_message": "One-line SOC alert",
  "remediation_steps": ["step1", "step2", "step3"],
  "block_recommended": true/false,
  "genai_verdict": "BLOCK / ALERT / MONITOR"
}"""

    user_message = f"""LIVE SECURITY EVENT — PRINTER IoT DEVICE

Printer: {printer_info['model']}
Printer IP: {printer_info['ip']}
Firmware: {printer_info['firmware']}
Timestamp: {get_timestamp()}

DETECTED EVENT:
Attack Type: {attack_data['name']}
Category: {attack_data['category']}
Attacker IP: {attack_data['attacker_ip']}
Severity Rating: {attack_data['severity']}
Description: {attack_data['description']}

RAW PAYLOAD DATA:
{json.dumps(attack_data['simulated_payload'], indent=2)}

Printer Current Status:
- Open Ports: {printer_info['open_ports']}
- SNMP Community: {printer_info['snmp_community']} (DEFAULT - NEVER CHANGED)
- Admin Credentials: {printer_info['admin_user']}/{printer_info['admin_pass']} (DEFAULT - NEVER CHANGED)
- Previous Alerts: {len(printer_info['alert_log'])} in session
- Blocked IPs: {printer_info['blocked_ips']}

Analyze this attack and provide your GenAI threat response as JSON."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ],
            temperature=0.3,
            max_tokens=1000,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result
        
    except Exception as e:
        # Fallback if API fails
        return {
            "threat_confirmed": True,
            "threat_name": attack_data['name'],
            "severity": attack_data['severity'],
            "confidence": 95,
            "attack_vector": attack_data['category'],
            "what_is_happening": f"Attack detected: {attack_data['description']}",
            "impact_if_unchecked": "Potential device compromise and data breach",
            "automated_actions": [
                "Blocking attacker IP immediately",
                "Disabling affected service port",
                "Alerting SOC team"
            ],
            "alert_message": f"⚠️ {attack_data['severity']} THREAT: {attack_data['name']} from {attack_data['attacker_ip']}",
            "remediation_steps": [
                "Change default credentials immediately",
                "Update firmware to latest version",
                "Enable network segmentation for printer VLAN"
            ],
            "block_recommended": True,
            "genai_verdict": "BLOCK",
            "error": str(e)
        }


# ── ROUTES ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", printer=printer_state, attacks=ATTACKS)


@app.route("/api/printer/status")
def printer_status():
    return jsonify({
        "printer": {
            "ip": printer_state["ip"],
            "model": printer_state["model"],
            "firmware": printer_state["firmware"],
            "status": printer_state["status"],
            "open_ports": printer_state["open_ports"],
            "services": printer_state["services"],
            "blocked_ips": printer_state["blocked_ips"],
            "alert_count": len(printer_state["alert_log"]),
            "job_count": len(printer_state["job_log"]),
        }
    })


@app.route("/api/attack/launch", methods=["POST"])
def launch_attack():
    """Simulate an attack and get GenAI analysis."""
    data = request.get_json()
    attack_key = data.get("attack_key")
    
    if attack_key not in ATTACKS:
        return jsonify({"error": "Unknown attack type"}), 400
    
    attack = ATTACKS[attack_key]
    timestamp = get_timestamp()
    
    # Log the attack event
    event = {
        "id": f"EVT-{random.randint(10000,99999)}",
        "timestamp": timestamp,
        "attack_key": attack_key,
        "attack_name": attack["name"],
        "attacker_ip": attack["attacker_ip"],
        "severity": attack["severity"],
        "payload": attack["simulated_payload"]
    }
    printer_state["job_log"].append(event)
    
    # Update printer status for critical attacks
    if attack["severity"] == "CRITICAL" and attack_key in ["default_creds", "firmware_tamper", "data_exfil"]:
        printer_state["status"] = "⚠️ UNDER ATTACK"
    elif attack_key in ["print_flood", "postscript_loop"]:
        printer_state["status"] = "🔴 DEGRADED"
    
    # Get GenAI analysis
    genai_response = analyze_with_genai(attack_key, attack, printer_state)
    
    # Apply automated actions — block the IP if recommended
    if genai_response.get("block_recommended") and attack["attacker_ip"] not in printer_state["blocked_ips"]:
        printer_state["blocked_ips"].append(attack["attacker_ip"])
        if printer_state["status"] == "⚠️ UNDER ATTACK":
            printer_state["status"] = "🛡️ PROTECTED (IP BLOCKED)"
        elif printer_state["status"] == "🔴 DEGRADED":
            printer_state["status"] = "🟡 RECOVERING"
    
    # Log the alert
    alert = {
        "id": event["id"],
        "timestamp": timestamp,
        "attack_name": attack["name"],
        "severity": genai_response.get("severity", attack["severity"]),
        "verdict": genai_response.get("genai_verdict", "ALERT"),
        "confidence": genai_response.get("confidence", 90),
        "attacker_ip": attack["attacker_ip"],
        "alert_message": genai_response.get("alert_message", ""),
        "blocked": genai_response.get("block_recommended", False)
    }
    printer_state["alert_log"].insert(0, alert)
    # Keep last 20 alerts
    printer_state["alert_log"] = printer_state["alert_log"][:20]
    
    return jsonify({
        "event": event,
        "genai_analysis": genai_response,
        "printer_status": printer_state["status"],
        "blocked_ips": printer_state["blocked_ips"]
    })


@app.route("/api/printer/reset", methods=["POST"])
def reset_printer():
    """Reset printer simulation state."""
    printer_state["status"] = "ONLINE"
    printer_state["job_log"] = []
    printer_state["alert_log"] = []
    printer_state["blocked_ips"] = []
    return jsonify({"message": "Printer state reset", "printer": printer_state})


@app.route("/api/alerts")
def get_alerts():
    return jsonify({"alerts": printer_state["alert_log"]})


@app.route("/api/genai/chat", methods=["POST"])
def genai_chat():
    """Free-form chat with the GenAI security assistant about the printer."""
    data = request.get_json()
    user_question = data.get("question", "")
    
    system_prompt = """You are GenAI-Shield, an IoT security AI protecting a network printer.
    
Current printer context:
- Device: HP LaserJet Pro M404n at 192.168.1.105  
- Known vulnerabilities: Default credentials (admin/admin), SNMP public community string, No firmware signing
- Active alerts this session: """ + str(len(printer_state["alert_log"])) + """
- Blocked IPs: """ + str(printer_state["blocked_ips"]) + """

Answer security questions about this printer, IoT security, and GenAI defense strategies.
Be specific, practical, and technical. Keep responses concise (3-5 sentences max)."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_question}
            ],
            temperature=0.5,
            max_tokens=300
        )
        return jsonify({"response": response.choices[0].message.content})
    except Exception as e:
        return jsonify({"response": f"GenAI-Shield offline: {str(e)}", "error": True})


if __name__ == "__main__":
    print("\n" + "="*60)
    print("  GenAI IoT Security Lab — Printer Attack Simulation")
    print("  Flask Server starting on http://localhost:5000")
    print("="*60 + "\n")
    app.run(debug=True, port=5000)